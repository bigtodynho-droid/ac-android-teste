AC EMPRÉSTIMOS & CELULARES — PACOTE DE COMPILAÇÃO ANDROID DE TESTE

Este pacote contém o aplicativo web e o fluxo GitHub Actions para compilar um APK debug.
Ele NÃO contém um APK compilado.

O arquivo www/config.js aponta para o projeto Supabase de TESTES:
https://angyhfrnmantqrsrrtgc.supabase.co
Não altere para o Supabase de produção.

Como usar: os arquivos e pastas deste ZIP precisam ser colocados na RAIZ de um repositório GitHub privado. Não envie este ZIP como um único arquivo para esperar que o GitHub o extraia automaticamente. O workflow roda ao enviar alterações para a branch principal/main e também pode ser iniciado manualmente em Actions.

Quando a execução concluir com sucesso, baixe o artefato AC-Celulares-TESTE-APK e extraia app-debug.apk.
Este APK é de depuração para testes, não para publicar na Play Store.
