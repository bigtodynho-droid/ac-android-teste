/* AC PWA V5.8 — cache apenas arquivos estáticos; nunca armazena respostas do Supabase/API. */
const CACHE_PREFIX = 'ac-pwa-shell-';
const CACHE_NAME = CACHE_PREFIX + 'v5-8-1';
const APP_SHELL = [
  './', './index.html', './style.css', './app.js', './config.js', './manifest.json',
  './icons/icon-192.png', './icons/icon-512.png', './icons/icon-maskable-512.png', './icons/apple-touch-icon.png'
];
const SUPABASE_CDN = 'https://cdn.jsdelivr.net/npm/@supabase/supabase-js@2';

self.addEventListener('install', event => {
  event.waitUntil(caches.open(CACHE_NAME).then(cache => cache.addAll(APP_SHELL)).then(() => self.skipWaiting()));
});

self.addEventListener('activate', event => {
  event.waitUntil(caches.keys().then(keys => Promise.all(
    keys.filter(key => key.startsWith(CACHE_PREFIX) && key !== CACHE_NAME).map(key => caches.delete(key))
  )).then(() => self.clients.claim()));
});

self.addEventListener('fetch', event => {
  const request = event.request;
  if (request.method !== 'GET') return;
  const url = new URL(request.url);

  // Cacheia somente a biblioteca JS do Supabase; nunca a API nem dados de clientes.
  if (url.origin === 'https://cdn.jsdelivr.net' && url.href === SUPABASE_CDN) {
    event.respondWith(fetch(request).then(response => {
      if (response && (response.ok || response.type === 'opaque')) {
        const copy = response.clone();
        caches.open(CACHE_NAME).then(cache => cache.put(request, copy)).catch(() => {});
      }
      return response;
    }).catch(async () => (await caches.match(request)) || Response.error()));
    return;
  }

  // Só atende arquivos do próprio site; chamadas externas (incluindo Supabase) ficam fora do cache.
  if (url.origin !== self.location.origin) return;
  const isNavigation = request.mode === 'navigate';
  if (isNavigation) {
    event.respondWith(fetch(request).then(response => {
      if (response && response.ok) caches.open(CACHE_NAME).then(cache => cache.put('./index.html', response.clone())).catch(() => {});
      return response;
    }).catch(async () => (await caches.match('./index.html')) || (await caches.match('./')) || Response.error()));
    return;
  }

  const path = url.pathname;
  const allowed = /\/(index\.html|app\.js|config\.js|style\.css|manifest\.json|sw\.js|icons\/[^/]+\.png)$/.test(path) || path.endsWith('/');
  if (!allowed) return;
  event.respondWith(caches.match(request).then(cached => {
    const update = fetch(request).then(response => {
      if (response && response.ok) caches.open(CACHE_NAME).then(cache => cache.put(request, response.clone())).catch(() => {});
      return response;
    });
    return cached || update.catch(() => Response.error());
  }));
});
