window.AC_CONFIG={
  SUPABASE_URL:'https://angyhfrnmantqrsrrtgc.supabase.co',
  SUPABASE_PUBLISHABLE_KEY:'sb_publishable_pXWoMwjajoq3l2zUOia69Q_82M1vYig'
};
